<script>
  // import HeroSection from "../lib/components/HeroSection.svelte";
  import {
    HeroSection,
    ChapterPreview,
    AuthorSection,
    FaqSection,
  } from "$components";
</script>

<HeroSection />
<ChapterPreview />
<AuthorSection />
<FaqSection />
