import {devExperience} from './devExperience'
import {project} from './project'
import {skills} from './skill'

export const schemaTypes = [devExperience, project, skills]
