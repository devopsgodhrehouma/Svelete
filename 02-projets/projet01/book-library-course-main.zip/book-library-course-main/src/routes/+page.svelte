<script lang="ts">
  import { HeroSection } from "$components";
</script>

<HeroSection />
