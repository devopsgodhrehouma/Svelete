<footer class="footer">
  <div class="footer-container">
    <h3 class="semi-bold mb-xs">Niklas Fischer</h3>
    <div class="mb-l">
      <a
        href="https://github.com/yourusername"
        target="_blank"
        class="footer-link">GitHub</a
      >
      <a
        href="https://linkedin.com/yourusername"
        target="_blank"
        class="footer-link">LinkedIn</a
      >
      <a
        href="https://twitter.com/yourusername"
        target="_blank"
        class="footer-link">Twitter</a
      >
    </div>
    <p>© 2024 Niklas Fischer. All rights reserved.</p>
  </div>
</footer>

<style>
  .footer {
    background-color: black;
    color: white;
    padding: 40px 20px;
    text-align: center;
  }

  .footer-link {
    margin: 0 10px;
  }
</style>
